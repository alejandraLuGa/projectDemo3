package towers.model.game_objects

import towers.model.physics.PhysicsVector

class Boundary(var start:PhysicsVector, var end: PhysicsVector) extends GameObject{

}
