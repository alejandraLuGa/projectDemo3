
var counter = -1;

function increment() {
    counter += 1;
    return counter
}

//test counter
console.log(counter);
console.log(increment ());
